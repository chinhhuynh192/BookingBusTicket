package com.busticketbooking.busticketbooking.dao;

public interface VehicleDao {

}
