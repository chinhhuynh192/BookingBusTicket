package com.busticketbooking.busticketbooking.Utils;

import com.busticketbooking.busticketbooking.models.Booking;

import javax.servlet.http.HttpSession;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class ConvertUtil {
    public static int convert(String str) throws NumberFormatException {
        return Integer.parseInt(str);
    }

    public static String formatTime(Time sqlTime) {
        // Convert java.sql.Time to LocalTime
        LocalTime localTime = sqlTime.toLocalTime();

        // Format LocalTime to display only hours and minutes
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        return localTime.format(formatter);
    }

    public static String formatDate(Date sqlDate) {
        // Convert java.sql.Date to LocalDate
        LocalDate localDate = sqlDate.toLocalDate();

        // Format LocalDate to display in 'DD-MM-YYYY'
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return localDate.format(formatter);
    }

    public static List<String> castStringListToList(String string){
        return Arrays.asList(string.split(",", -1));
    }

    public static List<Integer> getAllSeatNumbers(List<Booking> bookings) {
        return bookings.stream()
                .flatMap(booking -> Arrays.stream(booking.getSeatNumber().split(",")))
                .map(Integer::parseInt)
                .distinct()
                .collect(Collectors.toList());
    }
    public static int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    public static <T extends Serializable> T getAttr(String name, HttpSession sess) {
        @SuppressWarnings("unchecked")
        AttrWrapper<T> attr = (AttrWrapper<T>) sess.getAttribute(name);
        if (attr == null)
            return null;
        if (attr.isValid())
            return attr.value; // Attribute is valid, you can use it

        // Attribute is invalid, timed out, remove it
        sess.removeAttribute(name);
        return null;
    }
}
