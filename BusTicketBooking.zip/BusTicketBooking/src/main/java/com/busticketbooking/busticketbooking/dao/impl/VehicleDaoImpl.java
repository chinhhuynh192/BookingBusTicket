package com.busticketbooking.busticketbooking.dao.impl;

public class VehicleDaoImpl {
}
